package com.example.yaatris;

public class Company {
    public String name,email,phone,address;

    public Company(String cname,String cphone, String cemail,  String caddress){
        this.name = cname;
        this.phone = cphone;
        this.email = cemail;
        this.address = caddress;
    }

}
